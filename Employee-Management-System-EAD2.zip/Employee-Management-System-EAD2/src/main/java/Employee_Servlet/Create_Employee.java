package Employee_Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import DBConnection.ConnectDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/Create_Employees")

public class Create_Employee extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		String name = req.getParameter("name");
		String NIC = req.getParameter("NIC");
		String Department = req.getParameter("Department");
		String Designation = req.getParameter("Designation");
		String Joined_Date = req.getParameter("Joined_Date");
		
		Connection conn = null;
		
		PreparedStatement stmt = null;
		
		try {
			conn = ConnectDB.conDB();
			
			 String sql = "INSERT INTO employees (name, NIC, Department, Designation, Joined_Date) "
	                    + "VALUES (?, ?, ?, ?, ?)";
			 
			 stmt = conn.prepareStatement(sql);
			 
			 stmt.setString(1, name);
			 stmt.setString(2, NIC);
			 stmt.setString(3, Department);
			 stmt.setString(4, Designation);
			 stmt.setString(5, Joined_Date);
			 
			 int rowsInserted = stmt.executeUpdate();
			 
			 if(rowsInserted == 0)
			 {
				 throw new SQLException("Insert failed, no rows affected");
			 }
			 
			 res.sendRedirect("ViewEmployees");
		}catch(ClassNotFoundException | SQLException e)
		{
			throw new ServletException("Database error", e);
		}finally {
			if(stmt!=null)
			{
				try {
					stmt.close();
				}catch(SQLException e)
				{
					
				}
			}
			
			if(conn != null)
			{
				try
				{
					conn.close();
				}catch(SQLException e)
				{
					
				}
			}
		}
	}
}

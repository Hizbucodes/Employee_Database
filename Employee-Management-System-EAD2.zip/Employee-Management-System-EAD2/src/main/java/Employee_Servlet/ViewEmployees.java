package Employee_Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DBConnection.ConnectDB;
import Obj.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ViewEmployees extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	public ViewEmployees()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		try{
			Connection conn = ConnectDB.conDB();
			String sql = "SELECT * FROM employees";
	        PreparedStatement stmt = conn.prepareStatement(sql);
	        ResultSet rs = stmt.executeQuery();
	        
	        List<Employee> employeeList = new ArrayList<>();
	        
	        while (rs.next())
	        {
	        	Employee employee = new Employee();
	        	employee.setId(rs.getInt("id"));
	        	employee.setName(rs.getString("name"));
	        	employee.setNIC(rs.getString("NIC"));
	        	employee.setDepartment(rs.getString("Department"));
	        	employee.setDesignation(rs.getString("Designation"));
	        	employee.setJoined_Date(rs.getDate("Joined_Date"));
	        	
	        	employeeList.add(employee);
	        }
	        
	        rs.close();
	        stmt.close();
	        conn.close();
	        
	        request.setAttribute("employeeList", employeeList);
	        
	        RequestDispatcher dispatcher = request.getRequestDispatcher("View.jsp");
	        dispatcher.forward(request, response);
		}catch (SQLException e) {
	        e.printStackTrace();
		}catch (ClassNotFoundException e) {
	        e.printStackTrace();
	      
	    }
	}

}

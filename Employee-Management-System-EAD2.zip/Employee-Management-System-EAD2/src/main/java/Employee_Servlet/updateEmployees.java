package Employee_Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import DBConnection.ConnectDB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/updateEmployee")
public class updateEmployees extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException
	  {
		  int id = Integer.parseInt(request.getParameter("id"));
		  String NIC = request.getParameter("NIC");
		  String name = request.getParameter("name");
		  String Department = request.getParameter("Department");
		  String Designation = request.getParameter("Designation");
		  String Joined_Date = request.getParameter("Joined_Date");
		  
		  Connection conn = null;
	      PreparedStatement stmt = null;
	      
	      try {
	    	  
	    	  conn = ConnectDB.conDB();
	    	  
	    	  String sql = "UPDATE employees SET NIC = ?, name = ?, Department = ?, Designation = ?, Joined_Date = ? WHERE id = ?";
	    	  stmt = conn.prepareStatement(sql);
	    	  stmt.setInt(1, id);
	    	  stmt.setString(2, NIC);
	    	  stmt.setString(3, name);
	    	  stmt.setString(4, Department);
	    	  stmt.setString(5, Designation);
	    	  stmt.setString(6, Joined_Date);
	    	  
	    	  int rowsUpdated = stmt.executeUpdate();
	    	  
	    	  if (rowsUpdated == 0) {
	                throw new SQLException("Update failed, no rows affected");
	            }
	    	  
	    	  response.sendRedirect("ViewEmployees");
	      }catch (ClassNotFoundException | SQLException e)
	      {
	    	  throw new ServletException("Database error", e);
	      }finally
	      {
	    	  if (stmt != null)
	    	  {
	    		  try {
	                    stmt.close();
	                } catch (SQLException e) {
	                    // Ignore
	                }
	    	  }
	    	  
	    	  if (conn != null) {
	                try {
	                    conn.close();
	                } catch (SQLException e) {
	                    // Ignore
	                }
	    	  }
	      }
	      
	  }

}
